<script setup>
import Index from '@/views/Index.vue'

</script>

<template>
  <Index></Index>
</template>

<style scoped>

</style>